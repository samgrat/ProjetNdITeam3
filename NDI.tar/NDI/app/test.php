<?php
$args["tabTab"] = array(
	array("nom" => "MonNom1", "prenom" => "MonPrenom1"),
	array("nom" => "MonNom2", "prenom" => "MonPrenom2"),
	array("nom" => "MonNom3", "prenom" => "MonPrenom3")
)
echo "ll";
vardump($args);
?>
